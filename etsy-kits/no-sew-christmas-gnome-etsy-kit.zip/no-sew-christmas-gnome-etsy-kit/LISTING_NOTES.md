# No-Sew Christmas Gnome (NS 11) — Etsy Image Kit

Batch 1 of 2. Ten shots generated and upscaled to Etsy-recommended **2700×2025 (4:3)** masters in
`no-sew-christmas-gnome/etsy-ready/`. Previews (1200×896) sit beside them.

| # | File | Role | Suggested alt text |
|---|------|------|--------------------|
| 01 | 01-hero-santa-red | Main listing photo | Handmade crochet Christmas gnome in Santa red — plump one-piece body, white beard, bobble nose, soft pointed hat, about 12 cm (5 in) tall |
| 02 | 02-hero-forest-green | Colourway hero | Forest green no-sew crochet gnome, three-quarter view with a pine sprig |
| 03 | 03-colourways-lineup | Variants | Five colourways of the No-Sew Christmas Gnome: Santa red, Forest green, Nordic grey, Candy pink, Midnight navy |
| 04 | 04-macro-bobble-nose | Detail | Close-up of the 5-dc bobble nose with embroidered eyes one round above |
| 05 | 05-macro-spiral-stitches | Detail | Dense single-crochet fabric, spiral colour change, no seams — the no-sew look |
| 06 | 06-hands-scale | Scale | Gnome in cupped hands showing ~11–12.5 cm finished height |
| 07 | 07-size-ruler | Scale | Gnome beside a measuring tape: ~12 cm tall, 5 cm base, stands on its own |
| 08 | 08-materials-flatlay | Info | Pattern materials: worsted yarn in body/white/skin tone, 3.5 mm hook, fibre fill, stitch marker, tapestry needle |
| 09 | 09-tree-ornament | Lifestyle | Gnome hanging from a Christmas tree by the optional ch-18 loop |
| 10 | 10-mantel-trio | Lifestyle | Three gnomes styled on a mantel with pine, candle and fairy lights |

## Batch 2 (next) — shots 11–15 + a corrected red hero
11 hat-bend & brim detail (soft tip, optional white sl-st brim at the R15-16 line)
12 back view — seamless spiral, colour-change slant at the back
13 size variations — mini 8–9 cm / standard 11–12.5 cm / large ~15 cm
14 gift-boxed with kraft paper, ribbon, dried orange & pine
15 one-piece work-in-progress showing no assembly
16 re-shoot of 01 **without** the pom-pom (pattern tip is closed plain, optional hanging loop)

## Listing copy (title + 13 tags)
Title: *No-Sew Christmas Gnome Crochet Pattern — One Piece Amigurumi, Beginner PDF, US+UK Terms, Gnome Ornament*
Tags: christmas gnome pattern, no sew gnome, crochet gnome pdf, amigurumi gnome, gnome ornament, beginner crochet, holiday crochet, gnome gift idea, nordic gnome, one piece amigurumi, winter crochet, gnome decor, crochet pattern uk

Compliance note (from NS 11): never market finished gnomes as "baby-safe" or ASTM F963 / EN 71 compliant; credit "Novality Store" when selling finished items; do not redistribute the pattern itself.
