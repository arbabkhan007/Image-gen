# Novality Store - Etsy Image Kits (NS 11 - NS 15)

Every shot ships as a 1200x896 preview and a 2700x2025 (4:3, Etsy-recommended) master in `<kit>/etsy-ready/`.

## No-Sew Christmas Gnome (NS 11) - 0 shots

| # | File | Role | Alt text |
|---|------|------|----------|

Title: No-Sew Christmas Gnome Crochet Pattern - One Piece Amigurumi, Beginner PDF, US+UK Terms, Gnome Ornament
Tags: christmas gnome pattern, no sew gnome, crochet gnome pdf, amigurumi gnome, gnome ornament, beginner crochet, holiday crochet, gnome gift idea, nordic gnome, one piece amigurumi, winter crochet, gnome decor, crochet pattern uk

## Bobble Christmas Tree (NS 12) - 0 shots

| # | File | Role | Alt text |
|---|------|------|----------|

Title: Bobble Christmas Tree Crochet Pattern - One Piece Amigurumi Tree, Easy-Intermediate PDF, US+UK Terms, Bauble Bobbles
Tags: crochet tree pattern, bobble christmas tree, amigurumi tree, crochet tree pdf, christmas tree decor, bauble bobbles, holiday crochet, nordic christmas, tree ornament pattern, winter crochet, one piece crochet, easy crochet pattern, christmas table decor

## Christmas Ornament Bundle (NS 13) - 0 shots

| # | File | Role | Alt text |
|---|------|------|----------|

Title: Christmas Ornament Bundle Crochet Pattern - Bauble, Star & Snowflake, Beginner PDF, US+UK Terms
Tags: crochet ornament pattern, christmas bauble, crochet star, crochet snowflake, ornament bundle, gift topper, garland pattern, beginner crochet, window decor, leftover yarn project, holiday pdf, tree ornaments, nordic christmas

## Bobble Snowflake Tree Skirt (NS 14) - 0 shots

| # | File | Role | Alt text |
|---|------|------|----------|

Title: Bobble Snowflake Tree Skirt Crochet Pattern - 3 Sizes, Easy-Intermediate PDF, US+UK Terms
Tags: tree skirt pattern, crochet tree skirt, bobble crochet, snowflake skirt, christmas tree skirt, holiday home decor, scallop border, winter crochet, easy intermediate pdf, tree stand cover, festive floor decor, crochet skirt pdf, bobble snowflake

## Interchangeable Christmas Wreath (NS 15) - 0 shots

| # | File | Role | Alt text |
|---|------|------|----------|

Title: Interchangeable Christmas Wreath Crochet Pattern - 3 Removable Decorations, 3 Sizes, Beginner PDF
Tags: crochet wreath pattern, christmas wreath, door wreath, poinsettia crochet, removable decorations, interchangeable wreath, stuffed tube wreath, mini wreath ornament, winter white wreath, farmhouse wreath, beginner crochet pdf, holiday door decor, handmade wreath


## Compliance reminders
- NS 11/12: never market finished items as "baby-safe" or ASTM F963 / EN 71 compliant; no beads/bells on the tree; credit "Novality Store".
- NS 13: decorations, not toys; keep loops short and secured twice; no beads or glued additions.
- NS 14: home decor, not flameproof; keep away from flames/heaters; cool-running approved lights only.
- NS 15: use a load-rated hook and a load-rated cord/ribbon wrapped twice around the whole tube; never rely on crochet stitches or suction cups.
- The patterns themselves may not be redistributed; finished-item sales in small batches with credit are licensed.
